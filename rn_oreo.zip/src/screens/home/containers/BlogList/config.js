export const typeLayoutBlog = {
  row: 'row',
  column: 'column',
  list: 'list',
  carousel: 'carousel',
};

export const typeBlog = {
  latest: 'latest',
  custom: 'custom',
};

export const typeShowblog = {
  row: 'row',
  column: 'column',
  list: 'column',
  carousel: 'row',
};
