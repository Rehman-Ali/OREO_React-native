
export const typeLayoutCategory = {
  grid: 'grid',
  carousel: 'carousel',
};

export const typeShowCategory = {
  grid: 'grid',
  carousel: 'row',
};
export const categoryListType = {
  category1: 'category1',
  category2: 'category2',
  category3: 'category3',
  category4: 'category4',
};
