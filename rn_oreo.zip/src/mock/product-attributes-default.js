export const productAttributeDefault = [
  {
    id: 0,
    name: 'State',
    option: 'Re-sale',
  },
  {
    id: 3,
    name: 'Color',
    option: 'aqua',
  },
];
