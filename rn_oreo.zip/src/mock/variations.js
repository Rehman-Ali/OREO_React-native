export const productVariations1 = [
  {
    attributes: [
      {
        id: 0,
        name: 'State',
        option: 'Re-sale',
      },
    ],
  },
];

export const productVariations2 = [
  {
    attributes: [
      {
        id: 4,
        name: 'Size',
        option: 'M',
      },
      {
        id: 5,
        name: 'Image',
        option: 'Bamma',
      },
    ],
  },
];

export const productVariations3 = [
  {
    attributes: [
      {
        id: 4,
        name: 'Size',
        option: 'M',
      },
      {
        id: 5,
        name: 'Image',
        option: 'Bamma',
      },
    ],
  },
  {
    attributes: [
      {
        id: 4,
        name: 'Size',
        option: 'M',
      },
      {
        id: 5,
        name: 'Image',
        option: 'Bamma',
      },
    ],
  },
];
