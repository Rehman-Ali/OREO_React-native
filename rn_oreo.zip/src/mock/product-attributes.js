export const productAttributeNoTaxonomy = [
  {
    id: 0,
    name: 'State',
    position: 0,
    visible: true,
    variation: true,
    options: ['New', 'Re-sale'],
  },
];

export const productAttributeColor1 = [
  {
    id: 3,
    name: 'Color',
    position: 1,
    visible: true,
    variation: false,
    options: ['Aqua'],
  },
];

export const productAttributeColor2 = [
  {
    id: 3,
    name: 'Color',
    position: 1,
    visible: true,
    variation: false,
    options: ['Aqua', 'Black'],
  },
];
