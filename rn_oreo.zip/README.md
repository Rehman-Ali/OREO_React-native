![Build Android](https://build.appcenter.ms/v0.1/apps/634daa85-c3a6-4910-b997-13879c74028c/branches/testing/badge)
